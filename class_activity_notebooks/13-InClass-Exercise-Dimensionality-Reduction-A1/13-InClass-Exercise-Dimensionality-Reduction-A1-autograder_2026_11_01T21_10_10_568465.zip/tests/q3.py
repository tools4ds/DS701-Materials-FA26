from otter.test_files import test_case

OK_FORMAT = False

name = "q3"
points = 0

@test_case(points=None, hidden=False)
def test_recon_shape(X_recon, recon_frac, X):
    import numpy as np
    assert np.asarray(X_recon).shape == X.shape, 'X_recon must have the same shape as X'
    assert isinstance(recon_frac, float), 'recon_frac must be a float'
    assert 0.0 < recon_frac <= 0.1, 'with >= 90% variance retained you should lose at most 10% of the sum of squares'

@test_case(points=None, hidden=False)
def test_recon_matches_evr(recon_frac, cum_evr, n_components_90):
    import numpy as np
    assert np.isclose(recon_frac, 1 - np.asarray(cum_evr)[n_components_90 - 1], atol=1e-06), 'the lost fraction should equal 1 minus the cumulative explained variance at d'

@test_case(points=None, hidden=True)
def test_recon_values(X_recon, recon_frac, X_scaled, n_components_90, SECTION):
    import numpy as np
    from sklearn.decomposition import PCA
    p = PCA(n_components=n_components_90).fit(X_scaled)
    ref = p.inverse_transform(p.transform(X_scaled))
    assert np.allclose(np.asarray(X_recon), ref, atol=1e-08), 'X_recon must be the rank-d PCA reconstruction of X_scaled'
    expected = 0.0798
    assert abs(recon_frac - expected) < 0.002, f"recon_frac is not what section {SECTION}'s data gives"

