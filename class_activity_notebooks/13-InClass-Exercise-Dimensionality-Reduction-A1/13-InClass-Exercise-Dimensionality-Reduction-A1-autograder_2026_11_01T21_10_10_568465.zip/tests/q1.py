from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = 0

@test_case(points=None, hidden=False)
def test_scaled_shape(X_scaled, X):
    assert X_scaled is not None, 'X_scaled is not defined'
    assert X_scaled.shape == X.shape, 'X_scaled must have the same shape as X'

@test_case(points=None, hidden=False)
def test_scaled_moments(X_scaled):
    import numpy as np
    assert np.allclose(X_scaled.mean(axis=0), 0, atol=1e-08), 'every column of X_scaled must have mean 0'
    assert np.allclose(X_scaled.std(axis=0), 1, atol=1e-08), 'every column of X_scaled must have std 1'

@test_case(points=None, hidden=True)
def test_scaled_values(X_scaled, X, SECTION):
    import numpy as np
    n_expected = 13
    assert X.shape[1] == n_expected, f'section {SECTION} should be working on {n_expected} features'
    expected = (X - X.mean(axis=0)) / X.std(axis=0)
    assert np.allclose(X_scaled, expected), 'X_scaled must be the z-scored version of X (same column order)'

